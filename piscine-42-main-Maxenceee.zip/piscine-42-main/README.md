# Piscine 42 Lyon

My solutions for the September Piscine 2022. <br>
`Don't Copy, Learn.`

# Table of Content
| Projects      | Solutions  |
| :--------------:| :----------:|
| Shell00 | [100%](./shell_00) |
| Shell01 | [100%](./shell_01) |
| C00 | [100%](./c_00) | 
| C01 | [100%](./c_01) | 
| C02 | [100%](./c_02) | 
| C03 | [100%](./c_03) | 
| C04 | [100%](./c_04) | 
| C05 | [80%](./c_05) | 
| C06 | [100%](./c_06) | 
| C07 | [100%](./c_07) | 
| C08 | [100%](./c_08) |
| C09 | [100%](./c_09) | 
| C10 | [not rated](./c_10) | 
| C11 | [100%](./c_11) | 
| C12 | [not rated](./c_12) | 
| C13 | [not rated](./c_13) | 
| Exam00 | [64%] | 
| Exam01 | [80%] | 
| Exam02 | [84%] | 
| Exam03 | [72%] | 
| Rush00 | |
| Rush01 | [](./rush01)| 
| Rush02 | [](./rush02)| 
| BSQ | | 
 
### Notes

C_00 and C_02 has been corrected following the piscine.
Some were automatically evaluated by MOULINETTE but the results were replaced by 0.

`Enjoy coding and GOOD LUCK for your piscine.`

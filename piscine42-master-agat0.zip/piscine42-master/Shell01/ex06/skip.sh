ls -l | awk 'NR%2'

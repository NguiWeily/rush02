/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signe.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hmoulard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 21:13:40 by hmoulard          #+#    #+#             */
/*   Updated: 2022/08/23 21:16:44 by hmoulard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"ft.h"

int	addition(int a, int b)
{
	return (a + b);
}

int	diff(int a, int b)
{
	return (a - b);
}

int	div(int a, int b)
{
	return (a / b);
}

int	produit(int a, int b)
{
	return (a * b);
}

int	modulo(int a, int b)
{
	return (a % b);
}
